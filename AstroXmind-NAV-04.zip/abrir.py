from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import webbrowser

root = Path(__file__).resolve().parent
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
with ThreadingHTTPServer(("127.0.0.1", 8765), handler) as server:
    url = "http://127.0.0.1:8765/AstroXmind/navegacion/"
    print("NAV-04:", url, flush=True)
    print("Mantén esta ventana abierta mientras pruebas la wiki.", flush=True)
    webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
