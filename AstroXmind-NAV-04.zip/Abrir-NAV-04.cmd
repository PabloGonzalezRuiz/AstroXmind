@echo off
where py >nul 2>nul
if errorlevel 1 (
  python "%~dp0abrir.py"
) else (
  py -3 "%~dp0abrir.py"
)
if errorlevel 1 pause
